var http = require("http");

var options = {
    method: 'put',
    host: 'localhost',
    port: '3000',
    path: '/api'
}

callback = function (response) {
    var str = "";
    response.on("data", function (chunk) { str += chunk; });
    response.on("end", function () {
        console.log(str);

        http.request(deleteOptions, deletecallback).end();
    });
}
/*
var postOption1 = {
	method: 'post',
	host: 'localhost',
	port: '3000',
	path: '/api'
}
postCallback1 = function(response){
	var str = "";
	response.on("data", function(chunk){ str += chunk; });
	response.on("end", function(){
		console.log(str);
		
		myreq = http.request(postOption2, postCallback2);
		myreq.write(JSON.stringify(putdata2));
		myreq.end();
	});	
}
var postOption2 = {
	method: 'post',
	host: 'localhost',
	port: '3000',
	path: '/api'
}
postCallback2 = function(response){
	var str = "";
	response.on("data", function(chunk){ str += chunk; });
	response.on("end", function(){
		console.log(str);
		myreq = http.request(postOption3, postCallback3);
		myreq.write(JSON.stringify(putdata3));
		myreq.end();
	});	
}
var postOption3 = {
	method: 'post',
	host: 'localhost',
	port: '3000',
	path: '/api'
}
postCallback3 = function(response){
	var str = "";
	response.on("data", function(chunk){ str += chunk; });
	response.on("end", function(){
		console.log(str);
		
		http.request(deleteOptions, deletecallback).end();
	});	
}
*/

getcallback = function (response) {
    var str = "";
    response.on("data", function (chunk) { str += chunk; });
    response.on("end", function () {
        console.log(str);

      //  http.request(deleteOptions1, deletecallback1).end();
		/*
		myreq = http.request(options, callback);
		myreq.write(JSON.stringify(putdata));
		myreq.end();*/
    });
}

var getoptions = {
    method: 'get',
    host: 'localhost',
    port: '3000',
    path: '/api'
}


var deleteOptions = {
    method: 'delete',
    host: 'localhost',
    port: '3000',
    path: '/api/1'
}

deletecallback = function (response) {
    var str = "";
    response.on("data", function (chunk) { str += chunk; });
    response.on("end", function () {
        console.log(str);

        http.request(getoptions, getcallback).end();
    });
}

var deleteOptions1 = {
    method: 'delete',
    host: 'localhost',
    port: '3000',
    path: '/api'
}

deletecallback1 = function (response) {
    var str = "";
    response.on("data", function (chunk) { str += chunk; });
    response.on("end", function () {
        console.log(str);

    });
}

/*
var putdata1 = 
{	
	"item" : "Cat",
	"description" : "Likes to be lazy",
	"price" : "300"
}
var putdata2 = 
{	
	"item" : "Dog",
	"description" : "Wags tail when happy",
	"price" : "250"
}
var putdata3 = 
{	
	"item" : "Parrot",
	"description" : "Likes to sing",
	"price" : "500"
}

var putdata4 = 
{	
	"item" : "Rabbit",
	"description" : "Likes to eat carrots",
	"price" : "350"
}
*/
var putdata =
    {
        "coll": [{
            "item": "Bird",
            "description": "Has feathers",
            "price": "900"
        }, {
            "item": "Dog",
            "description": "Wags tail when happy",
            "price": "250"
        }, {
            "item": "Rabbit",
            "description": "Likes to eat carrots",
            "price": "350"
        }, {
            "item": "Parrot",
            "description": "Likes to sing",
            "price": "500"
        }, {
            "item": "Cat",
            "description": "Likes to be lazy",
            "price": "300"
        }]
    }


myreq = http.request(options, callback);
myreq.write(JSON.stringify(putdata));
myreq.end();
