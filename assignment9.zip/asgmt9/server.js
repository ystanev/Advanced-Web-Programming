var sqlite3 = require("sqlite3").verbose();
var db = new sqlite3.Database("asgmt9.db");
var express = require("express");
var app = express();

db.serialize(function () {
    db.run("DROP TABLE IF EXISTS coll");
    db.run("CREATE TABLE coll (item TEXT, description TEXT, price INTEGER)");

});

//GET the entire coll
app.get("/api", function (req, res) {
    console.log("GET REQUEST RECIEVED");

    db.all("SELECT rowid AS id, item, description, price FROM coll",
        function (err, results) {
            console.log(JSON.stringify(results));

            res.send(JSON.stringify(results));
        });
});

//GET the specific data
app.get("/api/:id", function (req, res) {
    console.log("GET REQUEST RECIEVED");

    db.all("SELECT rowid AS id, item, description, price FROM coll where id=" + req.params.id,
        function (err, results) {
            console.log(JSON.stringify(results));

            res.send(JSON.stringify(results));
        });
});

//PUT request to change the entire coll
app.put("/api", function (req, res) {
    console.log("PUT REQUEST RECIEVED");

    var str = "";
    req.on("data", function (chunk) { str += chunk; });
    req.on("end", function () {

        var reqObj = JSON.parse(str);

        console.log(str);

        db.serialize(function () {

            //db.run("DELETE FROM coll");
            var stmt = db.prepare("INSERT INTO coll (item, description, price) VALUES (?,?,?)");

            for (i = 0; i < reqObj.coll.length; i++) {
                stmt.run(reqObj.coll[i].item, reqObj.coll[i].description, reqObj.coll[i].price);
            }

			/*var stmt = db.prepare("UPDATE coll set item=(?), " + 
								  "description=(?), price=(?)");
			stmt.run(reqObj.item, reqObj.description, reqObj.price);*/
            stmt.finalize();

            res.send("coll UPDATED");
        });
    });

});

//PUT request to change a specific item
app.put("/api/:id", function (req, res) {
    console.log("PUT REQUEST RECIEVED");

    var str = "";
    req.on("data", function (chunk) { str += chunk; });
    req.on("end", function () {

        var reqObj = JSON.parse(str);

        console.log(str);

        db.serialize(function () {
            var stmt = db.prepare("UPDATE coll set item=(?), " +
                "description=(?), price=(?) WHERE rowid=" + req.params.id);
            stmt.run(reqObj.item, reqObj.description, reqObj.price);
            stmt.finalize();

            res.send("ITEM UPDATED");
        });
    });


});

//DELETE the entire coll
app.delete("/api", function (req, res) {
    console.log("DELETE REQUEST RECIEVED");

    db.run("DELETE FROM coll");
    res.send("coll DELETED");
});

//DELETE specific item
app.delete("/api/:id", function (req, res) {
    console.log("DELETE REQUEST RECIEVED");

    db.run("DELETE FROM coll where rowid=" + req.params.id);

    res.send("ITEM DELETED");
});

//POST
app.post("/api", function (req, res) {
    console.log("POST REQUEST RECIEVED");

    var str = "";
    req.on("data", function (chunk) { str += chunk; });
    req.on("end", function () {
        var reqObj = JSON.parse(str);

        console.log(str);

        db.serialize(function () {
            var stmt = db.prepare("INSERT INTO coll (item, description, price) VALUES (?,?,?)");
            stmt.run(reqObj.item, reqObj.description, reqObj.price);
            stmt.finalize();

            res.send("ITEM INSERTED");
        });
    });
});

var server = app.listen(3000, function () {
    console.log("RESTful API listening on port 3000!");
});