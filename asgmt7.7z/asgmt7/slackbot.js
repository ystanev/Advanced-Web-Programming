// Use the Slackbot package
var Bot = require("slackbots");

// Load in the http package to send http requests
var http = require("http");

// Helps us to build query strings
var querystring = require('querystring');

// Settings for our bot, must include name and token
var settings = {
  token: 'xoxb-327244532192-2fhy40fJtIt4SjSJmm2BC9R3',
  name: 'John Snow'
}

// Create the bot
var bot = new Bot(settings);

// The 'start' event occurs when the bot is first created
bot.on(
  'start',
  // Callback function, posts a message to the general channel
  function () {
    bot.postMessageToChannel(
      'general',
      'Winter is coming!'
    );
  }
);

// Handle the case of a "message" event in the Slackbot team.
// Note that a message isn't necessarily something that was 
// entered by a user in a channel... even a user typing 
// causes a message to appear.  Check out the basic slackbot
// example to analyze what's happening with messages.
bot.on(
  'message',
  function (data) {

    // for debugging, output the message data to the console
    console.log(data);

    // make sure the bot does not respond to itself!
    if (data.bot_id === "B9MSF1EAW") return;

    // only look at actual text messages, not messages like users 
    // typing, etc.
    if (data.type !== "message") return;

    // check for a command
    // First command is "What do you know?", bot should
    // respond with "I know nothing!"
    //
    // See the substr JS function: 
    //   https://www.w3schools.com/jsref/jsref_substr.asp
    if (data.text.substr(0, 17) == "What do you know?") { 
      bot.postMessageToChannel(
        'general',
        'I know nothing!'
      );

      // we return so that we don't output the default 
      // response to a message
      return;
    }

    // Let's make a joke command, that takes in a
    // joke number from 1-3.  Format is...
    //
    // Joke #
    //
    if (data.text.substr(0, 4) == "Joke") {
      // get the joke # (or command "argument")
      var num = data.text.substr(5, 6);

      // send a joke based on the joke number!
      if (num == 1) {
        bot.postMessageToChannel(
          'general',
          'Why did the chicken cross the road?\n\n' +
          'To get to the other side'
        );
      } else if (num == 2) {
        bot.postMessageToChannel(
          'general',
          'Why do cows go to New York?\n\n' +
          'To see the moosicals!'
        );
      } else {
        bot.postMessageToChannel(
          'general',
          'How do pickles celebrate their birthdays?\n\n' +
          'They relish the moment!'
        );
      }

      return;
    }

    // Geolocate an address and return a latitude and longitude.
    // Command has the format:
    //
    // Geo address
    //
    if (data.text.substr(0, 4) == "Geo ") {
      // Gets the remainder of the message string (i.e. the
      // address)
      var addr = data.text.substr(4);

      // Build a URL-friendly version of the address for 
      // our API call to the Google Geolocation API.
      var myreq = {
        'address': addr,
      };
      var myreqstr = querystring.stringify(myreq);

      // The options for our API call
      var options = {
        method: 'get',
        host: 'maps.googleapis.com',
        path: '/maps/api/geocode/json?' + myreqstr
      };

      // Handle the response to our API call
      callback = function (response) {

        // We get the response one "chunk" of data at a time.
        // Build a string that represents the response by 
        // appending each chunk.
        //
        // NodeJS has packages that take care of this sort of
        // thing for us, if you feel like learning something
        // extra! https://www.npmjs.com/package/body-parser
        //
        // However, for our purposes, this will suffice.
        //
        var str = '';
        response.on('data', function (chunk) {
          str += chunk;
        });

        // When the response has finished, send the long and lat
        // data in a message to the chat channel
        response.on('end', function () {
          // parse the string into a JSON object we can use
          var jsongeodata = JSON.parse(str);

          // post a message with the long/lat data
          bot.postMessageToChannel(
            'general',
            "Long: " +
            jsongeodata.results[0].geometry.location.lng +
            " " +
            "Lat: " +
            jsongeodata.results[0].geometry.location.lat);
        });
      }

      // make the request to the API with the options we've 
      // setup, have callback deal with the response
      http.request(options, callback).end();

      return;
    }

    // default message to send back if no commands detected
    bot.postMessageToChannel(
      'general',
      'Did somebody call me?'
    );

  }
);
