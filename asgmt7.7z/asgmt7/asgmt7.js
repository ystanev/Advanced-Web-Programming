// Use the Slackbot package
var Bot = require("slackbots");

// Load in the http package to send http requests
var http = require("http");

// Helps us to build query strings
var querystring = require('querystring');

var settings = {
    token: 'xoxb-330315287617-HH9WzEVInQnzd1MjRv21LUCS',
    name: 'Yury Bot'
};

// Create the bot
var bot = new Bot(settings);

///////////////////////////////////////////////////////////////////////////////

// The 'start' event occurs when the bot is first created
bot.on(
    'start',
    // Callback function, posts a message to the general channel
    function () {
        bot.postMessageToChannel(
            'general',
            'Hello World!'
        );
    }
);

bot.on(
    'message',
    function (data) {
        // for debugging, output the message data to the console
        console.log(data);

        // make sure the bot does not respond to itself!
        if (data.bot_id === "D9Q69MTNC") return;

        // only look at actual text messages, not messages like users 
        // typing, etc.
        if (data.type !== "message") return;

        ///////////////////////////////COMMANDS//////////////////////////////        

        // # 1 Command: About
        if (data.text.substr(0, 5) == "About") {
            bot.postMessageToChannel(
                'general',
                'This bot respondes to the command given by the user and return resonses.'
            );

            // we return so that we don't output the default response to a message
            return;
        }

        //////////////////////////////////////////////////////////////////////        

        // # 2-4 Commands: Joke #
        if (data.text.substr(0, 4) == "Joke") {
            // get the joke # (or command "argument")
            var num = data.text.substr(5, 6);

            // send a joke based on the joke number!
            if (num == 1) {
                bot.postMessageToChannel(
                    'general',
                    'What do you call a frozen dog?\n\n' +
                    'A pupsicle.'
                );
            }
            else if (num == 2) {
                bot.postMessageToChannel(
                    'general',
                    'What do you call a dog magician?\n\n' +
                    'A labracadabrador.'
                );
            }
            else {
                bot.postMessageToChannel(
                    'general',
                    'How did the little Scottish dog feel when he saw a monster?\n\n' +
                    'Terrier-fied!'
                );
            }

            return;
        }

        //////////////////////////////////////////////////////////////////////// 

        ///////////////////////////////HTTP REQUEST///////////////////////////// 

        if (data.text.substr(0, 5) == "Tides") {
            // The options for our API call
            var options = {
                method: 'get',
                host: 'geoportal.gc.ca',
                path: '/arcgis/rest/services/tides_marees/allstations_toutestations/MapServer?f=pjson'
            };

            // Handle the response to our API call
            callback = function (response) {

                var str = '';
                response.on('data', function (chunk) {
                    str += chunk;
                });

                response.on('end', function () {
                    // parse the string into a JSON object we can use
                    var jsondata = JSON.parse(str);

                    // post a message with service description to chat
                    /* bot.postMessageToChannel(
                        'general',
                        "Service Description:\n\n " + jsondata[0].results.serviceDescription
                    ); */

                    console.log(jsondata);
                }
                );

            }

            // make the request to the API with the options we've 
            // setup, have callback deal with the response
            http.request(options, callback).end();

            return;

        }

        //////////////////////////////////////////////////////////////////////// 

    }
);