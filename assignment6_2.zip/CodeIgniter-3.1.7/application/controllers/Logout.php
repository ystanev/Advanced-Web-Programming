<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout extends CI_Controller {

    var $TPL;

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code

        // is the user logged in or not?
        $this->TPL["loggedin"] = false;
        $this->session->sess_destroy(); //Destroys session

        // which page is active?
        $this->TPL['active'] = array('home' => false,
            'members'=>false,
            'admin' => false,
            'login'=>false);

    }

    public function index()
    {
        $this->template->show('logout', $this->TPL);
    }
}