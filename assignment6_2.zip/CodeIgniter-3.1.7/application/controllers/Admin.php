<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    var $TPL;

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code

        // is the user logged in or not?
        $this->TPL["loggedin"] = true;

        // which page is active?
        $this->TPL['active'] = array('home' => false,
            'members'=>false,
            'admin' => true,
            'login'=>false);

    }

    public function index()
    {
        $this->template->show('admin', $this->TPL);
    }

    public function viewUsers(){
        $query = $this->db->get('usersas6');

        echo '<table>';
        echo '<th>ID</th><th>Username</th><th>Password</th><th>Access Level</th>';
        foreach ($query->result() as $row)
        {
            echo '<tr>';
            echo '<td>' . $row->compid . '</td>';
            echo '<td>' . $row->username . '</td>';
            echo '<td>' . $row->password . '</td>';
            echo '<td>' . $row->accesslevel . '</td>';
            echo '<td>' . '<a href="index.php?/Admin/deleteuser/">Delete</a>' . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }

    public function addUser(){
        //Store form data into variables.
        $username = $_POST['username'];
        $password = $_POST['password'];
        $accesslevel = $_POST['accesslevel'];

        //Data Validation.
        if($accesslevel == 'admin' || $accesslevel== 'member'){
            $data = array(
                'username' => $username,
                'password' => $password,
                'accesslevel' => $accesslevel
            );

            $this->db->insert('usersas6', $data); //Query to inset data into table.
        }
        else{
            echo "Access Level may be either member or admin";
        }
    }

    public function deleteUser($id){
        $this->db->where('compid', $id);
        $this->db->delete('usersas6');
    }
}
