<h1>Login</h1>

<form action="index.php/Login/login" method="post">
    <input type="text" name="username" placeholder="Username"><br>
    <input type="text" name="password" placeholder="Password"><br>
    <input type="submit" value="Submit">
</form>