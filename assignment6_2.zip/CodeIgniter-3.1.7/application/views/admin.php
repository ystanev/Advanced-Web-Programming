<h2>Admin Page</h2>

<? /*$this->viewUsers()*/?>

<h3>Add User Form</h3>
<form action="index.php?/Admin/adduser" method="post">
    <input type="text" name="username" placeholder="Username"><br>
    <input type="text" name="password" placeholder="Password"><br>
    <input type="text" name="accesslevel" placeholder="Access Level"><br>
    <input type="submit" value="Submit">
</form>