<footer class="footer">
 <p >Copyright 2018</p>
 </footer>

 <br>

<pre>
<? print_r($_SESSION); ?>
</pre>

<pre>
<? print_r($_COOKIE); ?>
</pre>
</body>
</html>