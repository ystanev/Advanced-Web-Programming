<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    var $TPL;

    public function __construct()
    {
        parent::__construct();
        // Your own constructor code

        // is the user logged in or not?
        $this->TPL["loggedin"] = false;

        // which page is active?
        $this->TPL['active'] = array('home' => false,
            'members'=>false,
            'admin' => false,
            'login'=>true);

    }

    public function index()
    {
        $this->template->show('login', $this->TPL);
    }

    public function login(){
        //$this->db->select('username, password');
        $query = $this->db->get('usersas6');

        $username = $_POST['username'];
        $password = $_POST['password'];

        foreach ($query->result() as $row){
            if($username == $row->username && $password == $row->password){
                /*session_start();
                var_dump(session_start());*/

                $this->TPL["loggedin"] = true;

                if($row->accesslevel == 'admin'){
                    redirect('/Admin/');
                }
                elseif ($row->accesslevel == 'member'){
                    redirect('/Members/');
                }
            }
            else{
                //redirect('/Login/');
                echo "Wrong username or password." . '<br>';
            }
        }
    }
}